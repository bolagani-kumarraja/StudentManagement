
package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Pattern;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register-student")
public class StudentRegisterServlet extends HttpServlet {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws IOException {

        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("studentName");
        String email = request.getParameter("email");
        String department = request.getParameter("department");
        String yearText = request.getParameter("year");

        String error = null;
        int year = 0;

        // Validate the student's name
        if (name == null || name.trim().length() < 2
                || name.trim().length() > 100) {
            error = "Name must contain between 2 and 100 characters.";
        }

        // Validate email
        else if (email == null || email.length() > 100
                || !EMAIL_PATTERN.matcher(email.trim()).matches()) {
            error = "Please enter a valid email address.";
        }

        // Validate department
        else if (department == null ||
                !department.matches(
                        "CSE|ECE|EEE|IT|Mechanical")) {
            error = "Please select a valid department.";
        }

        // Validate year
        else {
            try {
                year = Integer.parseInt(yearText);

                if (year < 1 || year > 4) {
                    error = "Year must be between 1 and 4.";
                }
            } catch (NumberFormatException | NullPointerException e) {
                error = "Please select a valid year.";
            }
        }

        response.setContentType("text/html;charset=UTF-8");

        if (error != null) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head><meta charset='UTF-8'>");
        out.println("<title>Registration Result</title></head>");
        out.println("<body>");

        if (error != null) {
            out.println("<h1>Registration Failed</h1>");
            out.println("<p>" + escapeHtml(error) + "</p>");
        } else {
            out.println("<h1>Registration Successful!</h1>");
            out.println("<h2>Student Details</h2>");
            out.println("<p>Name: " + escapeHtml(name.trim()) + "</p>");
            out.println("<p>Email: " + escapeHtml(email.trim()) + "</p>");
            out.println("<p>Department: "
                    + escapeHtml(department) + "</p>");
            out.println("<p>Year: " + year + "</p>");
            out.println("<p>Note: Details are not saved to a database yet.</p>");
        }

        out.println("<a href='register.html'>Back to Registration</a>");
        out.println("</body></html>");
    }

    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
