package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/hello")
public class HelloServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>My First Servlet </title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Hello from Java Servlet! Kumar</h1>");
        out.println("<p>My Student Management project has started.</p>");
        out.println("<p>Java 17 + Tomcat 10.1</p>");
        out.println("</body>");
        out.println("</html>");
    }
}
