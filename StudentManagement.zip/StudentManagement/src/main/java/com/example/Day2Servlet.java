
package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/day2")
public class Day2Servlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        System.out.println("Day2Servlet: init() called");
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        System.out.println("Day2Servlet: doGet() called");

        
        response.setContentType("text/html;charset=UTF-8");

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Student Details</title>");
        out.println("</head>");
        out.println("<body>");

        out.println("<h1>Student Details Form</h1>");

        out.println("<form action='day2' method='post'>");

        out.println("Name: ");
        out.println("<input type='text' name='studentName' required>");
        out.println("<br><br>");

        out.println("Department: ");
        out.println("<input type='text' name='department' required>");
        out.println("<br><br>");

        out.println("<button type='submit'>Submit</button>");

        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        System.out.println("Day2Servlet: doPost() called");

        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("studentName");
        String department = request.getParameter("department");

        response.setContentType("text/html;charset=UTF-8");

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Submitted Details</title>");
        out.println("</head>");
        out.println("<body>");

        out.println("<h1>Student Details Submitted</h1>");
        out.println("<p>Name: " + escapeHtml(name) + "</p>");
        out.println("<p>Department: " + escapeHtml(department) + "</p>");

        out.println("<a href='day2'>Back to Form</a>");

        out.println("</body>");
        out.println("</html>");
    }

    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }

    @Override
    public void destroy() {
        System.out.println("Day2Servlet: destroy() called");
    }
}
